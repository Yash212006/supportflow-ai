from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class ApplePayPaymentDataType(str, Enum):
    """Indicates the type of payment data passed, in case of Non China the payment data is 3DSECURE and for China it is
    EMV."""

    _3_DSECURE = "3DSECURE"
    """The card was authenticated using 3D Secure (3DS) authentication scheme. While using this value make sure to
    populate cryptogram and eci_indicator as part of payment data.."""

    EMV = "EMV"
    """The card was authenticated using EMV method, which is applicable for China. While using this value make sure to
    pass emv_data and pin as part of payment data."""

    __str__ = str.__str__


ApplePayPaymentDataTypeOrStr: TypeAlias = Annotated[
    ApplePayPaymentDataType | str, open_enum_validator(ApplePayPaymentDataType)
]
